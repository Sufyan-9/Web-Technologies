function Navbar({ currentPage, setPage }) {
  return (
    <nav className="navbar fh-navbar">
      <div className="container-fluid">
        {/* Brand */}
        <a className="fh-brand" href="#" onClick={() => setPage('home')}>
          FASHION<span>HUB</span>
        </a>

        {/* Hamburger for mobile */}
        <button
          className="navbar-toggler border-0"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarMenu"
          style={{ color: 'var(--yellow)', fontSize: '1.4rem' }}
        >
          ☰
        </button>

        {/* Nav Links */}
        <div className="collapse navbar-collapse" id="navbarMenu">
          <div className="ms-auto d-flex flex-wrap gap-1 mt-2 mt-md-0 align-items-center">
            <button
              className={`fh-nav-btn ${currentPage === 'home' ? 'active' : ''}`}
              onClick={() => setPage('home')}
            >
              Home
            </button>
            <button
              className={`fh-nav-btn ${currentPage === 'products' ? 'active' : ''}`}
              onClick={() => setPage('products')}
            >
              Products
            </button>
            <button
              className={`fh-nav-btn ${currentPage === 'login' ? 'active' : ''}`}
              onClick={() => setPage('login')}
            >
              Login
            </button>
            <button
              className={`fh-nav-btn admin-btn ${currentPage === 'admin' ? 'active' : ''}`}
              onClick={() => setPage('admin')}
            >
              ⚡ Admin Panel
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
