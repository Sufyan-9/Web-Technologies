import CardPage from './CardPage.jsx';

const featuredItems = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&q=80',
    title: 'Signature Sneakers',
    description: 'Bold street-ready sneakers crafted for those who walk with confidence.',
    price: '$129.00',
    badge: 'NEW',
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=500&q=80',
    title: 'Power Dress',
    description: 'Effortlessly elegant evening dress. Turn heads wherever you go.',
    price: '$189.00',
    badge: 'HOT',
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=500&q=80',
    title: 'Urban Jacket',
    description: 'Premium cut streetwear jacket for the modern fashion-forward man.',
    price: '$219.00',
    badge: null,
  },
];

function HomePage({ setPage }) {
  return (
    <>
      {/* ─── Hero ─────────────────────────── */}
      <section className="fh-hero text-center text-md-start">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-md-7">
              <span className="fh-hero-tag fade-up">New Collection 2025</span>
              <h1 className="fh-hero-title fade-up fade-up-delay-1">
                DEFINE<br />YOUR <span>STYLE</span>
              </h1>
              <p className="fh-hero-sub fade-up fade-up-delay-2">
                Discover premium fashion that speaks before you do. Men's, Women's,
                Shoes & Accessories — all in one place.
              </p>
              <div className="d-flex gap-3 flex-wrap justify-content-center justify-content-md-start fade-up fade-up-delay-3">
                <button className="btn-fh-primary" onClick={() => setPage('products')}>
                  Shop Now
                </button>
                <button className="btn-fh-outline" onClick={() => setPage('login')}>
                  Join Us
                </button>
              </div>
            </div>

            <div className="col-md-5 mt-4 mt-md-0 text-center">
              <div
                style={{
                  display: 'inline-block',
                  background: 'var(--card-bg)',
                  border: '1px solid var(--border)',
                  borderRadius: '4px',
                  padding: '8px',
                }}
              >
                <img
                  src="https://images.unsplash.com/photo-1483985988355-763728e1935b?w=480&q=80"
                  alt="Fashion Model"
                  style={{
                    width: '100%',
                    maxWidth: '360px',
                    height: '420px',
                    objectFit: 'cover',
                    borderRadius: '2px',
                    display: 'block',
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─── Category Banners ─────────────── */}
      <section className="fh-section" style={{ background: 'var(--deep)' }}>
        <div className="container">
          <div className="text-center mb-4">
            <p className="fh-section-label">Browse Categories</p>
            <h2 className="fh-section-title mb-0">Shop By Collection</h2>
          </div>
          <div className="row g-3">
            {[
              {
                label: "Men's Wear",
                img: 'https://images.unsplash.com/photo-1617127365659-c47fa864d8bc?w=500&q=80',
              },
              {
                label: "Women's Wear",
                img: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=500&q=80',
              },
              {
                label: 'Footwear',
                img: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&q=80',
              },
              {
                label: 'Accessories',
                img: 'https://images.unsplash.com/photo-1523779917675-b6ed3a42a561?w=500&q=80',
              },
            ].map((cat) => (
              <div key={cat.label} className="col-6 col-md-3">
                <div
                  className="fh-card"
                  style={{ cursor: 'pointer' }}
                  onClick={() => setPage('products')}
                >
                  <img
                    src={cat.img}
                    alt={cat.label}
                    style={{ height: '180px', objectFit: 'cover' }}
                  />
                  <div className="fh-card-body text-center py-2">
                    <span
                      style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: '1.1rem',
                        letterSpacing: '1px',
                        color: 'var(--white)',
                      }}
                    >
                      {cat.label}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Featured Products ─────────────── */}
      <section className="fh-section">
        <div className="container">
          <div className="d-flex justify-content-between align-items-end mb-4 flex-wrap gap-2">
            <div>
              <p className="fh-section-label mb-1">Hand-picked</p>
              <h2 className="fh-section-title mb-0">Featured Products</h2>
            </div>
            <button className="btn-fh-outline" onClick={() => setPage('products')}>
              View All →
            </button>
          </div>
          <div className="row g-4">
            {featuredItems.map((item) => (
              <div key={item.id} className="col-md-4">
                <CardPage
                  {...item}
                  onBuy={() => alert(`"${item.title}" added to cart!`)}
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Promo Banner ─────────────────── */}
      <section
        style={{
          background: 'var(--yellow)',
          padding: '3rem 2rem',
          textAlign: 'center',
        }}
      >
        <div className="container">
          <h2
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(2rem, 5vw, 3.5rem)',
              color: 'var(--black)',
              letterSpacing: '2px',
              marginBottom: '0.5rem',
            }}
          >
            UP TO 40% OFF — SEASON SALE
          </h2>
          <p
            style={{
              color: '#333',
              fontWeight: 500,
              marginBottom: '1.5rem',
              fontSize: '1rem',
            }}
          >
            Limited time. Don't miss the biggest fashion event of the year.
          </p>
          <button
            style={{
              background: 'var(--black)',
              color: 'var(--yellow)',
              border: 'none',
              fontFamily: 'var(--font-body)',
              fontWeight: 700,
              fontSize: '0.85rem',
              letterSpacing: '1.5px',
              textTransform: 'uppercase',
              padding: '0.7rem 2rem',
              borderRadius: '2px',
              cursor: 'pointer',
              transition: 'opacity 0.2s',
            }}
            onClick={() => setPage('products')}
          >
            Shop the Sale
          </button>
        </div>
      </section>
    </>
  );
}

export default HomePage;
