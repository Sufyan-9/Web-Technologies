import { useState } from 'react';
import Navbar from './components/Navbar.jsx';
import HomePage from './components/HomePage.jsx';
import ProductPage from './components/ProductPage.jsx';
import LoginPage from './components/LoginPage.jsx';
import AdminPage from './components/AdminPage.jsx';
import UserPage from './components/UserPage.jsx';

function App() {
  const [currentPage, setCurrentPage] = useState('home');

  const setPage = (page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage setPage={setPage} />;
      case 'products':
        return <ProductPage setPage={setPage} />;
      case 'login':
        return <LoginPage setPage={setPage} />;
      case 'admin':
        return <AdminPage setPage={setPage} />;
      case 'user':
        return <UserPage setPage={setPage} />;
      default:
        return <HomePage setPage={setPage} />;
    }
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Navbar currentPage={currentPage} setPage={setPage} />

      <main style={{ flex: 1 }}>
        {renderPage()}
      </main>

      {/* Footer */}
      <footer className="fh-footer">
        <div className="fh-footer-brand">FASHIONHUB</div>
        <p className="fh-footer-copy">
          © 2025 Fashion Hub — All Rights Reserved · Men · Women · Shoes · Accessories
        </p>
        <div className="mt-2 d-flex justify-content-center gap-3">
          {['Home', 'Products', 'Login', 'Admin'].map((label) => (
            <button
              key={label}
              style={{
                background: 'none',
                border: 'none',
                color: 'var(--gray)',
                fontSize: '0.78rem',
                letterSpacing: '1px',
                textTransform: 'uppercase',
                cursor: 'pointer',
                transition: 'color 0.2s',
              }}
              onMouseOver={(e) => (e.target.style.color = 'var(--yellow)')}
              onMouseOut={(e) => (e.target.style.color = 'var(--gray)')}
              onClick={() => setPage(label.toLowerCase().replace(' panel', ''))}
            >
              {label}
            </button>
          ))}
        </div>
      </footer>
    </div>
  );
}

export default App;
