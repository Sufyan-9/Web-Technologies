function CardPage({ image, title, description, price, badge, onBuy }) {
  return (
    <div className="fh-card h-100">
      <div style={{ overflow: 'hidden', position: 'relative' }}>
        {badge && (
          <span
            className="fh-badge position-absolute"
            style={{ top: '12px', left: '12px', zIndex: 2 }}
          >
            {badge}
          </span>
        )}
        <img src={image} alt={title} loading="lazy" />
      </div>
      <div className="fh-card-body d-flex flex-column">
        <h5 className="fh-card-title">{title}</h5>
        <p className="fh-card-desc flex-grow-1">{description}</p>
        <div className="fh-card-price">{price}</div>
        <button className="btn-fh-primary w-100" onClick={onBuy}>
          Buy Now
        </button>
      </div>
    </div>
  );
}

export default CardPage;
