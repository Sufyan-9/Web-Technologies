import { useState } from 'react';
import CardPage from './CardPage.jsx';

const allProducts = [
  {
    id: 1,
    category: 'Men',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&q=80',
    title: 'Men Shoes',
    description: 'Premium leather oxfords. Handcrafted for the modern professional who demands style and comfort.',
    price: '$149.00',
    badge: 'NEW',
  },
  {
    id: 2,
    category: 'Women',
    image: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=500&q=80',
    title: 'Women Dress',
    description: 'Flowing midi dress with elegant silhouette. Perfect for any occasion — from casual to formal.',
    price: '$189.00',
    badge: 'HOT',
  },
  {
    id: 3,
    category: 'Men',
    image: 'https://images.unsplash.com/photo-1516257984-b1b4d707412e?w=500&q=80',
    title: 'Casual Wear',
    description: 'Relaxed fit casual shirt. Ultra-soft fabric with a versatile look for everyday comfort.',
    price: '$79.00',
    badge: null,
  },
  {
    id: 4,
    category: 'Shoes',
    image: 'https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=500&q=80',
    title: 'Sneakers',
    description: 'Street-ready sneakers with cushioned soles and bold design. Built for all-day wear.',
    price: '$129.00',
    badge: 'SALE',
  },
  {
    id: 5,
    category: 'Women',
    image: 'https://images.unsplash.com/photo-1523359346063-d879354c0ea5?w=500&q=80',
    title: 'Denim Jacket',
    description: 'Classic denim jacket with a modern slim cut. Layer it over any outfit for instant edge.',
    price: '$159.00',
    badge: null,
  },
  {
    id: 6,
    category: 'Accessories',
    image: 'https://images.unsplash.com/photo-1523779917675-b6ed3a42a561?w=500&q=80',
    title: 'Leather Bag',
    description: 'Genuine leather crossbody bag. Minimalist and spacious — your everyday essential.',
    price: '$219.00',
    badge: 'PREMIUM',
  },
  {
    id: 7,
    category: 'Men',
    image: 'https://images.unsplash.com/photo-1617127365659-c47fa864d8bc?w=500&q=80',
    title: 'Slim Suit',
    description: 'Tailored slim-fit suit jacket. Sharp lines, premium wool blend, boardroom-ready.',
    price: '$349.00',
    badge: 'NEW',
  },
  {
    id: 8,
    category: 'Shoes',
    image: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=500&q=80',
    title: 'Heels',
    description: 'Strappy block-heel sandals. Comfortable height with a glamorous finish.',
    price: '$109.00',
    badge: null,
  },
];

const categories = ['All', 'Men', 'Women', 'Shoes', 'Accessories'];

function ProductPage() {
  const [activeCategory, setActiveCategory] = useState('All');
  const [cart, setCart] = useState([]);

  const filtered =
    activeCategory === 'All'
      ? allProducts
      : allProducts.filter((p) => p.category === activeCategory);

  const handleBuy = (product) => {
    setCart((prev) => [...prev, product]);
    alert(`✅ "${product.title}" added to cart! (${cart.length + 1} items)`);
  };

  return (
    <div className="fh-section">
      <div className="container">
        {/* Header */}
        <div className="row align-items-end mb-4">
          <div className="col">
            <p className="fh-section-label mb-1">Our Collection</p>
            <h2 className="fh-section-title mb-0">All Products</h2>
          </div>
          <div className="col-auto">
            <span
              style={{
                background: 'var(--card-bg)',
                border: '1px solid var(--border)',
                borderRadius: '3px',
                padding: '0.4rem 1rem',
                fontSize: '0.82rem',
                color: 'var(--yellow)',
                fontWeight: 600,
              }}
            >
              🛒 Cart: {cart.length}
            </span>
          </div>
        </div>

        {/* Category Filter */}
        <div className="d-flex flex-wrap gap-2 mb-4">
          {categories.map((cat) => (
            <button
              key={cat}
              className={activeCategory === cat ? 'btn-fh-primary' : 'btn-fh-outline'}
              style={{ fontSize: '0.78rem', padding: '0.45rem 1.2rem' }}
              onClick={() => setActiveCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Product Grid */}
        <div className="row g-4">
          {filtered.map((product) => (
            <div key={product.id} className="col-sm-6 col-lg-3">
              <CardPage {...product} onBuy={() => handleBuy(product)} />
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-5">
            <p style={{ color: 'var(--gray)', fontSize: '1.1rem' }}>
              No products found in this category.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default ProductPage;
