import CardPage from './CardPage.jsx';

const userProducts = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&q=80',
    title: 'Men Shoes',
    description: 'Premium leather oxfords for the modern professional.',
    price: '$149.00',
    badge: 'NEW',
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=500&q=80',
    title: 'Women Dress',
    description: 'Flowing midi dress — perfect for any occasion.',
    price: '$189.00',
    badge: 'HOT',
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=500&q=80',
    title: 'Sneakers',
    description: 'Bold street-ready sneakers built for all-day wear.',
    price: '$129.00',
    badge: 'SALE',
  },
];

const orders = [
  { id: '#FH-2048', item: 'Men Shoes', date: 'May 01, 2025', status: 'Delivered' },
  { id: '#FH-2049', item: 'Sneakers', date: 'Apr 22, 2025', status: 'Shipped' },
  { id: '#FH-2050', item: 'Women Dress', date: 'Apr 10, 2025', status: 'Delivered' },
];

function UserPage({ setPage }) {
  return (
    <div className="fh-section">
      <div className="container">

        {/* Welcome Banner */}
        <div
          className="mb-5 fade-up"
          style={{
            background: 'var(--card-bg)',
            border: '1px solid var(--border)',
            borderLeft: '4px solid var(--yellow)',
            borderRadius: '4px',
            padding: '2rem',
            display: 'flex',
            alignItems: 'center',
            gap: '1.5rem',
            flexWrap: 'wrap',
          }}
        >
          <div
            style={{
              width: '72px',
              height: '72px',
              borderRadius: '50%',
              background: 'var(--yellow)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontFamily: 'var(--font-display)',
              fontSize: '2rem',
              color: 'var(--black)',
              flexShrink: 0,
            }}
          >
            JD
          </div>
          <div>
            <p className="fh-section-label mb-1">Member Since 2025</p>
            <h2
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '2rem',
                letterSpacing: '1px',
                color: 'var(--white)',
                marginBottom: '0.2rem',
              }}
            >
              Welcome back, John!
            </h2>
            <p style={{ color: 'var(--gray)', fontSize: '0.9rem', margin: 0 }}>
              john@email.com · Premium Member ⭐
            </p>
          </div>
        </div>

        {/* Stats Row */}
        <div className="row g-3 mb-5 fade-up fade-up-delay-1">
          {[
            { num: '12', label: 'Total Orders' },
            { num: '3', label: 'Wishlist Items' },
            { num: '$820', label: 'Total Spent' },
            { num: '4.8★', label: 'Member Rating' },
          ].map((s) => (
            <div key={s.label} className="col-6 col-md-3">
              <div className="fh-stat-card">
                <div className="fh-stat-number">{s.num}</div>
                <div className="fh-stat-label">{s.label}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Order History */}
        <div className="mb-5 fade-up fade-up-delay-2">
          <p className="fh-section-label mb-1">History</p>
          <h3 className="fh-section-title">My Orders</h3>
          <div
            style={{
              background: 'var(--card-bg)',
              border: '1px solid var(--border)',
              borderRadius: '4px',
              overflow: 'hidden',
            }}
          >
            <table className="table mb-0" style={{ color: 'var(--white)' }}>
              <thead>
                <tr
                  style={{
                    background: 'var(--black)',
                    borderBottom: '1px solid var(--border)',
                  }}
                >
                  {['Order ID', 'Item', 'Date', 'Status'].map((h) => (
                    <th
                      key={h}
                      style={{
                        color: 'var(--yellow)',
                        fontFamily: 'var(--font-body)',
                        fontWeight: 700,
                        fontSize: '0.75rem',
                        letterSpacing: '1.5px',
                        textTransform: 'uppercase',
                        padding: '0.9rem 1.2rem',
                        border: 'none',
                      }}
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {orders.map((o) => (
                  <tr
                    key={o.id}
                    style={{ borderBottom: '1px solid var(--border)' }}
                  >
                    <td
                      style={{
                        padding: '0.9rem 1.2rem',
                        border: 'none',
                        fontFamily: 'var(--font-display)',
                        letterSpacing: '1px',
                        color: 'var(--yellow)',
                      }}
                    >
                      {o.id}
                    </td>
                    <td style={{ padding: '0.9rem 1.2rem', border: 'none' }}>
                      {o.item}
                    </td>
                    <td
                      style={{
                        padding: '0.9rem 1.2rem',
                        border: 'none',
                        color: 'var(--gray)',
                        fontSize: '0.85rem',
                      }}
                    >
                      {o.date}
                    </td>
                    <td style={{ padding: '0.9rem 1.2rem', border: 'none' }}>
                      <span
                        style={{
                          background:
                            o.status === 'Delivered'
                              ? 'rgba(34,197,94,0.15)'
                              : 'rgba(245,197,24,0.15)',
                          color:
                            o.status === 'Delivered' ? '#22c55e' : 'var(--yellow)',
                          fontSize: '0.72rem',
                          fontWeight: 700,
                          letterSpacing: '1px',
                          textTransform: 'uppercase',
                          padding: '0.2rem 0.7rem',
                          borderRadius: '2px',
                        }}
                      >
                        {o.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recommended */}
        <div className="fade-up fade-up-delay-3">
          <p className="fh-section-label mb-1">For You</p>
          <div className="d-flex justify-content-between align-items-end mb-4">
            <h3 className="fh-section-title mb-0">Recommended Products</h3>
            <button className="btn-fh-outline" onClick={() => setPage('products')}>
              View All →
            </button>
          </div>
          <div className="row g-4">
            {userProducts.map((p) => (
              <div key={p.id} className="col-md-4">
                <CardPage
                  {...p}
                  onBuy={() => alert(`"${p.title}" added to cart!`)}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default UserPage;
