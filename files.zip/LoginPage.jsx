import { useState } from 'react';

function LoginPage({ setPage }) {
  const [mode, setMode] = useState('login'); // 'login' | 'register'
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    address: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.email || !form.password) {
      alert('Please fill in all required fields.');
      return;
    }
    setSubmitted(true);
    setTimeout(() => {
      setPage('user');
    }, 1200);
  };

  if (submitted) {
    return (
      <div
        className="d-flex align-items-center justify-content-center"
        style={{ minHeight: '80vh' }}
      >
        <div className="text-center fade-up">
          <div
            style={{
              width: '70px',
              height: '70px',
              background: 'var(--yellow)',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '2rem',
              margin: '0 auto 1.2rem',
            }}
          >
            ✓
          </div>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', letterSpacing: '1px' }}>
            {mode === 'login' ? 'Welcome Back!' : 'Account Created!'}
          </h3>
          <p style={{ color: 'var(--gray)' }}>Redirecting to your profile…</p>
        </div>
      </div>
    );
  }

  return (
    <div
      className="d-flex align-items-center justify-content-center py-5"
      style={{ minHeight: '85vh', background: 'var(--deep)' }}
    >
      <div className="container">
        <div className="fh-form-card fade-up">
          {/* Header */}
          <div className="text-center mb-4">
            <h2 className="fh-form-title">
              {mode === 'login' ? 'SIGN IN' : 'REGISTER'}
            </h2>
            <p className="fh-form-subtitle">
              {mode === 'login'
                ? 'Welcome back. Enter your details to continue.'
                : 'Create your Fashion Hub account today.'}
            </p>
            <div className="fh-divider mx-auto" />
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit}>
            {/* Name (always shown, required for register) */}
            <div className="mb-3">
              <label className="fh-label d-block">
                Full Name {mode === 'login' && <span style={{ color: 'var(--gray)', fontWeight: 400 }}>(optional)</span>}
              </label>
              <input
                type="text"
                name="name"
                className="form-control fh-input"
                placeholder="John Doe"
                value={form.name}
                onChange={handleChange}
              />
            </div>

            {/* Email */}
            <div className="mb-3">
              <label className="fh-label d-block">Email *</label>
              <input
                type="email"
                name="email"
                className="form-control fh-input"
                placeholder="you@email.com"
                value={form.email}
                onChange={handleChange}
                required
              />
            </div>

            {/* Password */}
            <div className="mb-3">
              <label className="fh-label d-block">Password *</label>
              <input
                type="password"
                name="password"
                className="form-control fh-input"
                placeholder="••••••••"
                value={form.password}
                onChange={handleChange}
                required
              />
            </div>

            {/* Address */}
            <div className="mb-4">
              <label className="fh-label d-block">
                Address {mode === 'login' && <span style={{ color: 'var(--gray)', fontWeight: 400 }}>(optional)</span>}
              </label>
              <input
                type="text"
                name="address"
                className="form-control fh-input"
                placeholder="123 Main St, City, Country"
                value={form.address}
                onChange={handleChange}
              />
            </div>

            {/* Buttons */}
            <div className="d-grid gap-2">
              <button type="submit" className="btn-fh-primary">
                {mode === 'login' ? 'Sign In' : 'Create Account'}
              </button>
              <button
                type="button"
                className="btn-fh-outline"
                onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
              >
                {mode === 'login' ? 'New here? Register' : 'Already have an account? Login'}
              </button>
            </div>
          </form>

          {/* Footer note */}
          <p
            className="text-center mt-3"
            style={{ fontSize: '0.75rem', color: 'var(--gray)' }}
          >
            By continuing, you agree to our Terms of Service & Privacy Policy.
          </p>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
