import { useState } from 'react';

const staticProducts = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=200&q=80',
    title: 'Men Shoes',
    category: 'Men',
    price: '$149.00',
    stock: 24,
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=200&q=80',
    title: 'Women Dress',
    category: 'Women',
    price: '$189.00',
    stock: 18,
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=200&q=80',
    title: 'Sneakers',
    category: 'Shoes',
    price: '$129.00',
    stock: 42,
  },
  {
    id: 4,
    image: 'https://images.unsplash.com/photo-1523779917675-b6ed3a42a561?w=200&q=80',
    title: 'Leather Bag',
    category: 'Accessories',
    price: '$219.00',
    stock: 9,
  },
];

function AdminPage() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [form, setForm] = useState({
    name: '',
    category: '',
    price: '',
    description: '',
    stock: '',
  });
  const [addedProducts, setAddedProducts] = useState([]);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleAddProduct = (e) => {
    e.preventDefault();
    if (!form.name || !form.price) {
      alert('Product name and price are required.');
      return;
    }
    const newProd = { ...form, id: Date.now(), image: null };
    setAddedProducts((prev) => [...prev, newProd]);
    setForm({ name: '', category: '', price: '', description: '', stock: '' });
    alert(`✅ Product "${newProd.name}" added successfully!`);
  };

  const allView = [...staticProducts, ...addedProducts];

  const menuItems = [
    { key: 'dashboard', label: '📊 Dashboard' },
    { key: 'add', label: '➕ Add Product' },
    { key: 'products', label: '📦 View Products' },
    { key: 'orders', label: '🛒 Orders' },
    { key: 'settings', label: '⚙️ Settings' },
  ];

  return (
    <div className="d-flex" style={{ minHeight: 'calc(100vh - 60px)' }}>
      {/* Sidebar */}
      <div className="fh-admin-sidebar d-none d-md-block" style={{ width: '220px', flexShrink: 0 }}>
        <p
          style={{
            fontFamily: 'var(--font-display)',
            fontSize: '0.9rem',
            letterSpacing: '2px',
            color: 'var(--yellow)',
            marginBottom: '1.5rem',
            paddingLeft: '1rem',
          }}
        >
          ADMIN PANEL
        </p>
        {menuItems.map((item) => (
          <button
            key={item.key}
            className={`fh-admin-menu-item ${activeTab === item.key ? 'active' : ''}`}
            onClick={() => setActiveTab(item.key)}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Mobile tab row */}
      <div className="d-md-none w-100 position-absolute" style={{ top: '60px', zIndex: 50 }}>
        <div
          className="d-flex overflow-auto"
          style={{ background: 'var(--card-bg)', borderBottom: '1px solid var(--border)' }}
        >
          {menuItems.map((item) => (
            <button
              key={item.key}
              className={`fh-nav-btn ${activeTab === item.key ? 'active' : ''}`}
              style={{ whiteSpace: 'nowrap', fontSize: '0.7rem' }}
              onClick={() => setActiveTab(item.key)}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-grow-1 p-4" style={{ paddingTop: '2rem' }}>

        {/* ── Dashboard ── */}
        {activeTab === 'dashboard' && (
          <div className="fade-up">
            <p className="fh-section-label mb-1">Overview</p>
            <h2 className="fh-section-title">Admin Dashboard</h2>
            <div className="row g-3 mb-4">
              {[
                { num: '128', label: 'Total Orders' },
                { num: '42', label: 'Products' },
                { num: '$12,480', label: 'Revenue' },
                { num: '96', label: 'Customers' },
              ].map((s) => (
                <div key={s.label} className="col-6 col-lg-3">
                  <div className="fh-stat-card">
                    <div className="fh-stat-number">{s.num}</div>
                    <div className="fh-stat-label">{s.label}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Recent activity */}
            <div
              style={{
                background: 'var(--card-bg)',
                border: '1px solid var(--border)',
                borderRadius: '4px',
                padding: '1.5rem',
              }}
            >
              <h5
                style={{
                  fontFamily: 'var(--font-display)',
                  letterSpacing: '1px',
                  color: 'var(--yellow)',
                  marginBottom: '1rem',
                }}
              >
                RECENT ACTIVITY
              </h5>
              {[
                { icon: '🛒', text: 'New order #FH-2051 placed', time: '2 min ago' },
                { icon: '👤', text: 'New user Sarah J. registered', time: '14 min ago' },
                { icon: '📦', text: 'Sneakers stock updated to 42', time: '1 hr ago' },
                { icon: '💬', text: 'New review on Women Dress', time: '3 hr ago' },
              ].map((a, i) => (
                <div
                  key={i}
                  className="d-flex justify-content-between align-items-center py-2"
                  style={{ borderBottom: '1px solid var(--border)' }}
                >
                  <span style={{ fontSize: '0.9rem' }}>
                    {a.icon} {a.text}
                  </span>
                  <span style={{ fontSize: '0.75rem', color: 'var(--gray)' }}>{a.time}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── Add Product ── */}
        {activeTab === 'add' && (
          <div className="fade-up" style={{ maxWidth: '560px' }}>
            <p className="fh-section-label mb-1">Inventory</p>
            <h2 className="fh-section-title">Add New Product</h2>
            <div
              style={{
                background: 'var(--card-bg)',
                border: '1px solid var(--border)',
                borderRadius: '4px',
                padding: '2rem',
              }}
            >
              <form onSubmit={handleAddProduct}>
                <div className="mb-3">
                  <label className="fh-label d-block">Product Name *</label>
                  <input
                    type="text"
                    name="name"
                    className="form-control fh-input"
                    placeholder="e.g. Classic Blazer"
                    value={form.name}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="row g-3 mb-3">
                  <div className="col">
                    <label className="fh-label d-block">Category</label>
                    <select
                      name="category"
                      className="form-control fh-input"
                      value={form.category}
                      onChange={handleChange}
                    >
                      <option value="">Select…</option>
                      <option>Men</option>
                      <option>Women</option>
                      <option>Shoes</option>
                      <option>Accessories</option>
                    </select>
                  </div>
                  <div className="col">
                    <label className="fh-label d-block">Price *</label>
                    <input
                      type="text"
                      name="price"
                      className="form-control fh-input"
                      placeholder="$0.00"
                      value={form.price}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
                <div className="mb-3">
                  <label className="fh-label d-block">Stock Quantity</label>
                  <input
                    type="number"
                    name="stock"
                    className="form-control fh-input"
                    placeholder="0"
                    value={form.stock}
                    onChange={handleChange}
                  />
                </div>
                <div className="mb-4">
                  <label className="fh-label d-block">Description</label>
                  <textarea
                    name="description"
                    className="form-control fh-input"
                    rows={3}
                    placeholder="Short product description…"
                    value={form.description}
                    onChange={handleChange}
                    style={{ resize: 'vertical' }}
                  />
                </div>
                <div className="d-flex gap-2">
                  <button type="submit" className="btn-fh-primary flex-grow-1">
                    Add Product
                  </button>
                  <button
                    type="button"
                    className="btn-fh-outline"
                    onClick={() => setForm({ name: '', category: '', price: '', description: '', stock: '' })}
                  >
                    Clear
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ── View Products ── */}
        {activeTab === 'products' && (
          <div className="fade-up">
            <p className="fh-section-label mb-1">Inventory</p>
            <h2 className="fh-section-title">
              All Products
              <span
                style={{
                  fontFamily: 'var(--font-body)',
                  fontSize: '1rem',
                  color: 'var(--gray)',
                  marginLeft: '1rem',
                }}
              >
                ({allView.length} items)
              </span>
            </h2>
            <div className="row g-3">
              {allView.map((p, i) => (
                <div key={p.id ?? i} className="col-sm-6 col-xl-3">
                  <div
                    className="fh-card"
                    style={{ display: 'flex', flexDirection: 'column' }}
                  >
                    {p.image ? (
                      <img
                        src={p.image}
                        alt={p.title || p.name}
                        style={{ height: '160px', objectFit: 'cover' }}
                      />
                    ) : (
                      <div
                        style={{
                          height: '160px',
                          background: 'var(--black)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '2.5rem',
                        }}
                      >
                        📦
                      </div>
                    )}
                    <div className="fh-card-body flex-grow-1">
                      <div className="fh-card-title">{p.title || p.name}</div>
                      <div
                        style={{
                          fontSize: '0.75rem',
                          color: 'var(--gray)',
                          marginBottom: '0.5rem',
                        }}
                      >
                        {p.category || 'Uncategorized'}
                        {p.stock !== undefined && p.stock !== '' && (
                          <> · Stock: {p.stock}</>
                        )}
                      </div>
                      <div className="fh-card-price">{p.price}</div>
                      <div className="d-flex gap-2">
                        <button
                          className="btn-fh-outline"
                          style={{ fontSize: '0.72rem', padding: '0.35rem 0.8rem', flex: 1 }}
                          onClick={() => alert('Edit functionality (UI only)')}
                        >
                          Edit
                        </button>
                        <button
                          style={{
                            background: 'rgba(239,68,68,0.15)',
                            color: '#ef4444',
                            border: '1px solid #ef4444',
                            fontSize: '0.72rem',
                            padding: '0.35rem 0.8rem',
                            borderRadius: '2px',
                            cursor: 'pointer',
                            flex: 1,
                          }}
                          onClick={() => alert('Delete functionality (UI only)')}
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── Orders ── */}
        {activeTab === 'orders' && (
          <div className="fade-up">
            <p className="fh-section-label mb-1">Management</p>
            <h2 className="fh-section-title">All Orders</h2>
            <div
              style={{
                background: 'var(--card-bg)',
                border: '1px solid var(--border)',
                borderRadius: '4px',
                overflow: 'hidden',
              }}
            >
              <table className="table mb-0" style={{ color: 'var(--white)' }}>
                <thead>
                  <tr style={{ background: 'var(--black)' }}>
                    {['Order', 'Customer', 'Product', 'Amount', 'Status'].map((h) => (
                      <th
                        key={h}
                        style={{
                          color: 'var(--yellow)',
                          fontWeight: 700,
                          fontSize: '0.72rem',
                          letterSpacing: '1.5px',
                          textTransform: 'uppercase',
                          padding: '0.9rem 1.2rem',
                          border: 'none',
                        }}
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[
                    { id: '#FH-2051', cust: 'Sarah J.', prod: 'Women Dress', amt: '$189', status: 'Pending' },
                    { id: '#FH-2050', cust: 'Mike T.', prod: 'Men Shoes', amt: '$149', status: 'Shipped' },
                    { id: '#FH-2049', cust: 'John D.', prod: 'Sneakers', amt: '$129', status: 'Delivered' },
                    { id: '#FH-2048', cust: 'Anna K.', prod: 'Leather Bag', amt: '$219', status: 'Delivered' },
                  ].map((o) => (
                    <tr key={o.id} style={{ borderBottom: '1px solid var(--border)' }}>
                      <td
                        style={{
                          padding: '0.9rem 1.2rem',
                          border: 'none',
                          fontFamily: 'var(--font-display)',
                          color: 'var(--yellow)',
                          letterSpacing: '1px',
                        }}
                      >
                        {o.id}
                      </td>
                      <td style={{ padding: '0.9rem 1.2rem', border: 'none' }}>{o.cust}</td>
                      <td style={{ padding: '0.9rem 1.2rem', border: 'none', color: 'var(--gray)' }}>
                        {o.prod}
                      </td>
                      <td
                        style={{
                          padding: '0.9rem 1.2rem',
                          border: 'none',
                          fontWeight: 600,
                        }}
                      >
                        {o.amt}
                      </td>
                      <td style={{ padding: '0.9rem 1.2rem', border: 'none' }}>
                        <span
                          style={{
                            background:
                              o.status === 'Delivered'
                                ? 'rgba(34,197,94,0.15)'
                                : o.status === 'Shipped'
                                ? 'rgba(245,197,24,0.15)'
                                : 'rgba(99,102,241,0.15)',
                            color:
                              o.status === 'Delivered'
                                ? '#22c55e'
                                : o.status === 'Shipped'
                                ? 'var(--yellow)'
                                : '#818cf8',
                            fontSize: '0.72rem',
                            fontWeight: 700,
                            letterSpacing: '1px',
                            textTransform: 'uppercase',
                            padding: '0.2rem 0.7rem',
                            borderRadius: '2px',
                          }}
                        >
                          {o.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ── Settings ── */}
        {activeTab === 'settings' && (
          <div className="fade-up" style={{ maxWidth: '480px' }}>
            <p className="fh-section-label mb-1">Configuration</p>
            <h2 className="fh-section-title">Settings</h2>
            <div
              style={{
                background: 'var(--card-bg)',
                border: '1px solid var(--border)',
                borderRadius: '4px',
                padding: '2rem',
              }}
            >
              {['Store Name', 'Admin Email', 'Currency', 'Tax Rate (%)'].map((field) => (
                <div key={field} className="mb-3">
                  <label className="fh-label d-block">{field}</label>
                  <input
                    type="text"
                    className="form-control fh-input"
                    defaultValue={
                      field === 'Store Name'
                        ? 'Fashion Hub'
                        : field === 'Admin Email'
                        ? 'admin@fashionhub.com'
                        : field === 'Currency'
                        ? 'USD ($)'
                        : '8'
                    }
                  />
                </div>
              ))}
              <button className="btn-fh-primary w-100 mt-2">Save Settings</button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}

export default AdminPage;
